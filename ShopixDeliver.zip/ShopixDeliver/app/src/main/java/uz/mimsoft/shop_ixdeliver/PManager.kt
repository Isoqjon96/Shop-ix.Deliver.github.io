package uz.mimsoft.shop_ixdeliver

import android.preference.PreferenceManager

object PManager{
    private val preferenceManager by lazy {
        return@lazy PreferenceManager.getDefaultSharedPreferences(App.getInstance())
    }

}